package com.SystemRecommendationOpenReq.SystemRecomendation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SystemRecomendationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SystemRecomendationApplication.class, args);
	}
}
